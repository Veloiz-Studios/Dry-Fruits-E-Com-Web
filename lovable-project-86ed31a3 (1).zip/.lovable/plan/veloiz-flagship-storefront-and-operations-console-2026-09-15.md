# Veloiz flagship storefront and operations console

## Outcome
Build a complete premium dry-fruits commerce experience with a warm editorial storefront and a precise authenticated admin console. Customer browsing remains public; admin access uses email and password without a separate profile table.

## Storefront
- Create a shared editorial shell with responsive navigation, live cart count, cart drawer, and premium footer.
- Build the home page with an asymmetric product-led opening, six-category visual wall, bestselling products, sourcing/freshness story, and catalog call-to-action.
- Add a searchable/filterable catalog with category, price, availability, refined product cards, and a considered empty state.
- Add product detail pages with image gallery, live weight pricing, segmented weight control, quantity stepper, stock messaging, Add to Cart, and Buy Now.
- Add a polished cart drawer, single-column checkout with order summary, secure Razorpay-ready payment state, and order confirmation with status progress.
- Ensure mobile storefront controls are spacious and touch-friendly.

## Admin console
- Add email/password sign-in using Lovable Cloud authentication, with no profile table, social login, or public sign-up.
- Protect all `/admin` management screens with both authentication and a server-enforced allow-list for one manually provisioned admin email; authenticated customers can never gain admin access.
- Build the operational shell with sidebar, top bar, quick actions, and responsive navigation.
- Add dashboard metrics and recent orders.
- Add product management with search, category filters, status controls, stock/price editing, and product image upload flow.
- Add category management, order management with status pipeline and CSV export of the currently filtered/visible orders, inventory adjustments with low-stock flags, and business settings.
- Prioritize dashboard, orders, and inventory for mobile.

## Data and behavior
- Model products, variants, categories, orders, order items, inventory, and business settings in Lovable Cloud with secure access rules.
- Seed the requested category and realistic product catalog so the first screen is complete.
- Keep cart state client-side until checkout; persist completed orders and inventory changes.
- Integrate Razorpay test mode through environment-configured secure server-side functions, so moving to live mode only requires swapping keys.
- Create the payment attempt at checkout, then mark the order Paid and decrement inventory atomically only after server-side Razorpay signature verification; failed or abandoned payments never reduce stock.

## Visual system
- Use warm ivory, cream, espresso, taupe, restrained saffron-gold, and muted olive semantic tokens.
- Pair a high-contrast editorial serif with a neutral sans-serif.
- Use asymmetry, generous negative space, tactile packaging-like surfaces, subtle paper grain, restrained shadows, and minimal motion.
- Keep admin layouts grid-aligned, dense, and undecorated.
- Generate a cohesive placeholder set of premium, product-forward dry-fruit imagery, with generic image fields and upload handling so real photography can replace it without structural changes.

## Validation
- Verify customer flows, cart calculations, product filters, checkout states, admin access, CRUD-style controls, order status updates, inventory adjustments, and CSV export.
- Check desktop and mobile layouts for overlap, readable typography, and touch targets.
- Add unique metadata for every public and admin page.
