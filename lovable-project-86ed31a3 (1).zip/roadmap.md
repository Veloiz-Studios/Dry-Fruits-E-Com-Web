# Veloiz roadmap

- [ ] Restrict admin access to one manually provisioned allow-listed account; no public admin signup
- [ ] Configure Razorpay test mode through environment variables for key-only live migration
- [ ] Keep product imagery replaceable through the generic image upload flow
- [ ] Export only currently filtered and visible orders to CSV
- [ ] Verify Razorpay signatures server-side before marking paid or decrementing inventory
